(function(){
  chrome.browserAction.onClicked.addListener(function(tab) { 
    chrome.tabs.getSelected(null, function(tab) {  
      alert(tab.url);
    });  
  });
})();